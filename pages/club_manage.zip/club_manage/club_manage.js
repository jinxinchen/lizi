var local = [];
var length_all;
var app = getApp()
Page({
  data: {
    club_activity:{},
    club_people:{},
    // club_id:null,
    club_id: 1,
    // user_id:null,
    user_id: 2,
    data_record: {},     //社团记忆数据
    winWidth: 0,
    winHeight: 0,
    // tab切换  
    currentTab: 0,
    num: 198,
    pictureSrc: '',
    PeopleName: '',
    PeopleIntro: '',
    HeadSrc: '',
    time: '',
    bola: true,
    bolb: false,
    bola: false,
    column: 'http://wxapp1.b0.upaiyun.com/yzl/img/column.png',
    background: 'http://wxapp1.b0.upaiyun.com/yzl/img/backgroud.png',
    p1: 'http://wxapp1.b0.upaiyun.com/yzl/img/p1.png',
    p2: 'http://wxapp1.b0.upaiyun.com/yzl/img/p2.png',
    p3: 'http://wxapp1.b0.upaiyun.com/yzl/img/p3.png',
    head: 'http://wxapp1.b0.upaiyun.com/yzl/img/head.png',
    more: 'http://wxapp1.b0.upaiyun.com/yzl/img/more.png',
    back: 'http://wxapp1.b0.upaiyun.com/yzl/img/back.png',
    icon_first: 'http://wxapp1.b0.upaiyun.com/ljq/img/mine/class.png',
    icon_second: 'http://wxapp1.b0.upaiyun.com/ljq/img/mine/club.png',
    icon_third: 'http://wxapp1.b0.upaiyun.com/ljq/img/mine/activity.png',
    icon_fourth: 'http://wxapp1.b0.upaiyun.com/yzl/img/show.png',
    hotclub: "http://wxapp1.b0.upaiyun.com/yzl/img/hotclub.png",
    img: "http://wxapp1.b0.upaiyun.com/ljq/img/demo.jpg",
    time: "2016年7月8日",
    xueyuan: "厦门华侨大学计算机科学与技术学院",
    menpiao: "门票",
    title: "科技创新大赛",
    data: []
  },
  return: function () {
    console.log(0)
    wx.navigateBack({
      delta: 1, // 回退前 delta(默认为1) 页面
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })

  },
  onLoad: function (e) {
    var that = this;
    that.setData({club_id:e.club_id});
    // console.log(that.data.club_id)
    // console.log("2222222222222222")
    /*获取系统信息*/
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
    var that = this;
    wx.request({
      url: 'https://api.lizi123.cn/index.php/home/Club/clubImpress',
      data: {
        'client_type': 0,
        "club_id": that.data.club_id,
      },
      header: { 'content-type': 'application/x-www-form-urlencoded' },
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      success: function (res) {
        console.log(res)
        that.setData({club_activity:res.data.activity_image,
        club_people:res.data.member
})
        // console.log(that.data.data_record)
        // console.log(res.data[0]);
        // that.setData({ num: res.data[0].club_id });
        // that.setData({
        //   data_record: res.data,
        //   pictureSrc: res.data[0].images[0],
        //   PeopleName: res.data[0].user_info.user_name,
        //   PeopleIntro: res.data[0].user_info.intro,
        //   HeadSrc: res.data[0].user_info.head_image,
        //   time: res.data[0].time
        // });

      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  /* 滑动切换tab */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /*点击tab切换*/
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  toMine: function () {
    wx.switchTab({//返回有tabbar的页面
      url: '../mine/mine'
    })
  },
  onShow: function () {
    var that = this;
    wx.request({
      url: 'https://api.lizi123.cn/index.php/home/club/wxgetHotActivity',
      data: {},
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res);
        length_all = res.data.length;
        local = Array.prototype.slice.call(res.data);
        // local=res.data;
        // local.splice(1,1);
        // console.log(local);
        that.setData({
          data: local,
        })
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },
  return: function () {
    wx.navigateBack({
      delta: 1, // 回退前 delta(默认为1) 页面
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  deletes: function (e) {
    console.log(e.target.id);
    var delete_id = e.target.id;
    console.log(local);
    local = Array.prototype.slice.call(local);
    local.splice(delete_id, 1);
    console.log(local);
    // console.log(local);
    this.setData({
      data: local,
    })
  }
})